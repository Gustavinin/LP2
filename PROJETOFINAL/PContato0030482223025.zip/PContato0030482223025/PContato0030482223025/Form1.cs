﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;

namespace PContato0030482223025
{
    public partial class Form1 : Form
    {
        public static SqlConnection conexao;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular 
                conexao = new SqlConnection("Data Source=SATNOTE11\\SQLEXPRESS;Initial Catalog=LP2;Integrated Security=True"); 
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }

        }

        private void cidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
                    {

                MessageBox.Show("Formulario existente");
                Application.OpenForms["frmCidade"].BringToFront();

            }
            else
            {
                frmCidade Objc = new frmCidade();
                Objc.MdiParent = this;
                Objc.WindowState = FormWindowState.Maximized;
                Objc.Show();

            }
        }

        private void contatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {

                MessageBox.Show("Formulario existente");
                Application.OpenForms["frmContato"].BringToFront();

            }
            else
            {
                frmContato Objc = new frmContato();
                Objc.MdiParent = this;
                Objc.WindowState = FormWindowState.Maximized;
                Objc.Show();

            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Sobre>().Count() > 0)
            {

                MessageBox.Show("Formulario existente");
                Application.OpenForms["Sobre"].BringToFront();

            }
            else
            {
                Sobre Objc = new Sobre();
                Objc.MdiParent = this;
                Objc.WindowState = FormWindowState.Maximized;
                Objc.Show();

            }
        }

        private void sairToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
            System.Environment.Exit(1);
        }
    }
}
