﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482223025
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();

        public frmContato()
        {
            InitializeComponent();
        }

        private void frmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtIDContato.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndereco.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelular.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpData.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];

                cbxCidade.DisplayMember = "nome_cidade";

                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar contato");
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            bnContato.AddNew();
            txtNomeContato.Enabled = true;
            txtEndereco.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            cbxCidade.Enabled = true;
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;
            dtpData.Enabled = true;
            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No",
           MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
           == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.Idcontato = Convert.ToInt32(txtIDContato.Text);

                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluída com sucesso!","SUCESSO");

                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(RegCon.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Contato!");
                }
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            // validar os dados
            if (txtNomeContato.Text == "")
            {
                MessageBox.Show("Nome inválido!", "DADO INVÁLIDO");
            }
            else if (txtEndereco.Text == "")
            {
                MessageBox.Show("Endereço inválido!", "DADO INVÁLIDO");
            }
            else if (cbxCidade.Text == "")
            {
                MessageBox.Show("Cidade inválida!", "DADO INVÁLIDO");
            }
            else if (txtCelular.Text == "")
            {
                MessageBox.Show("Celular inválido!", "DADO INVÁLIDO");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("E-mail inválido!", "DADO INVÁLIDO");
            }
            else if (dtpData.Value == null)
            {
                MessageBox.Show("Data inválida!", "DADO INVÁLIDO");
            }
            else
            {
                Contato RegCon = new Contato();
                RegCon.Nomecontato = txtNomeContato.Text;
                RegCon.Endcontato = txtEndereco.Text;
                RegCon.Cidadecontato = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegCon.Celcontato = txtCelular.Text;
                RegCon.Emailcontato = txtEmail.Text;
                RegCon.Dtcadastrocontato = dtpData.Value;

                if (bInclusao)
                {
                    if (RegCon.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionada com sucesso!", "SUCESSO");
                       
                        txtNomeContato.Enabled = false;
                        txtEndereco.Enabled = false;
                        txtCelular.Enabled = false;
                        txtEmail.Enabled = false;
                        dtpData.Enabled = false;
                        cbxCidade.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        // recarrega o grid
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCon.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!", "ERRO");
                    }
                }
                else
                {
                    RegCon.Idcontato = Convert.ToInt32(txtIDContato.Text);
                    if (RegCon.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterada com sucesso!");
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCon.Listar());
                        txtNomeContato.Enabled = false;
                        txtEndereco.Enabled = false;
                        txtCelular.Enabled = false;
                        txtEmail.Enabled = false;
                        dtpData.Enabled = false;
                        cbxCidade.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        bInclusao = false;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!");
                    }
                }
            }

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNomeContato.Enabled = true;
            txtEndereco.Enabled = true;
            cbxCidade.Enabled = true;
            txtCelular.Enabled = true;
            txtEmail.Enabled = true;
            dtpData.Enabled = true;
            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();
            txtNomeContato.Enabled = false;
            txtEndereco.Enabled = false;
            txtCelular.Enabled = false;
            txtEmail.Enabled = false;
            dtpData.Enabled = false;
            cbxCidade.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;
            bInclusao = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
